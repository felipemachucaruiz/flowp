const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('printBridge', {
  getPrinters: () => ipcRenderer.invoke('get-printers'),
  getConfig: () => ipcRenderer.invoke('get-config'),
  saveConfig: (config) => ipcRenderer.invoke('save-config', config),
  getServerStatus: () => ipcRenderer.invoke('get-server-status'),
  testPrint: () => ipcRenderer.invoke('test-print'),
  testKitchenPrint: () => ipcRenderer.invoke('test-kitchen-print'),
  getAuthToken: () => ipcRenderer.invoke('get-auth-token'),
  regenerateToken: () => ipcRenderer.invoke('regenerate-token'),
  setLanguage: (lang) => ipcRenderer.invoke('set-language', lang),
  getLanguage: () => ipcRenderer.invoke('get-language'),
  onServerStatus: (callback) => {
    ipcRenderer.on('server-status', (event, status) => callback(status));
  }
});
